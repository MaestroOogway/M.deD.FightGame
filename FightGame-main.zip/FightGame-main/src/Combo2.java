
public class Combo2 {
    public void MakeCombo(Luchador l)
    {
        System.out.println(l.golpear() +l.saltar() +l.patear());

    }
}
