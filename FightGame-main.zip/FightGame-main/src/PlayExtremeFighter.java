import java.io.Console;

public class PlayExtremeFighter {
	public static void main(String[] args) {
		// new FightEngine();

		CreateVariant[] variants = new CreateVariant[2];

		variants[0] = new Tank();
		variants[1] = new Assasin();
		
		variants[0].CreateVariant();
		variants[1].CreateVariant();

        MakeCombo makecombo= new MakeCombo();
       
        
        //Luchador l = new ChoroPortenho(0, 0, 0, 0, 0);
        //Luchador l2 = new MineroWarrior(0, 0, 0, 0, 0);
        makecombo.IsEligible();
        makecombo.IsEligible2();
	
		//Main menu

		for (CreateVariant variant : variants) {
			System.out.println("\n" + variant.getClass().getName() + "--");
			for (Luchador luchador : variant.getListaluchador()) {
				
				System.out.println(" " + luchador.getClass().getName() +"\nHealth:" + luchador.health + "\nArmor:" + luchador.armor + "\nPower:" + luchador.power + "\nMan�:" + luchador.mana + "\nAtack" + luchador.atack);
			}
		}    


		// Display document pages
		
		

	}
}



