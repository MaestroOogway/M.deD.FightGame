import java.io.Console;

public class PlayExtremeFighter {
	public static void main(String[] args) {
		new FightEngine();

	}
}
