
public class EstadoBajo implements Estado {
	
	
	public String golpear() {
		// TODO Auto-generated method stub
		return "Golpe Bajo";
	}

	public String patear() {
		// TODO Auto-generated method stub
		return "Patada baja";
	}


}
