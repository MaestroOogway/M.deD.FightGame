
public interface Estado {
	
	
	public abstract String golpear();
	public abstract String patear();


}
