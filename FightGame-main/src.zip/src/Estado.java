
public interface Estado {
	
	
	public abstract String golpear(Luchador ch);
	public abstract String patear(Luchador ch);


}
