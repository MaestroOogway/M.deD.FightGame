
public class EstadoBajo implements Estado {
	
	Luchador ch = new ChoroPortenho(0, 0, 0, 0, 0);

	public String golpear(Luchador ch) {
		// TODO Auto-generated method stub
		return "Golpe Bajo de Anguila";
	}

	public String patear(Luchador ch) {
		// TODO Auto-generated method stub
		return "Patada baja de molusco";
	}


}
