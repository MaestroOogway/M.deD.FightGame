
public class Combo1 {
	public void MakeCombo(Luchador l) {
		System.out.println(l.patear() + l.golpear());

	}
}
