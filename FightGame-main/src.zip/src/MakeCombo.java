
public class MakeCombo {
	Combo1 combo1 = new Combo1();
	Combo2 combo2 = new Combo2();
	Luchador l = new ChoroPortenho(0, 0, 0, 0, 0);
	Luchador l2 = new MineroWarrior(0, 0, 0, 0, 0);

	public void IsEligible() {
		combo1.MakeCombo(l);

	}

	public void IsEligible2() {
		combo2.MakeCombo(l2);
	}
}